# rk_django_hello_world
Projeto Django (sem BD) para demonstrar um website simples (Hello World)

virtualenv venv

source venv/bin/activate (Linux)

.\venv\Scripts\activate (Windows)

pip install django

python manage.py runserver

(Acesse via Navegador: http://127.0.0.1:8000)
